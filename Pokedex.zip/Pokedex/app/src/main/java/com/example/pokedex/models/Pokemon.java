package com.example.pokedex.models;

public class Pokemon {
    private int number;
    public String name;
    public String url;
    public String imageUrl;

    public int getNumber() {
        String[] urlPartes = url.split("/");
        return Integer.parseInt(urlPartes[urlPartes.length - 1]);
    }

    public void setNumber(int number) {
        this.number = number;
    }

}
