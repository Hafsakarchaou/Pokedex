package com.example.pokedex;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;

public class DetailsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details_layout);
        Intent intent = getIntent();
        String name = intent.getStringExtra(MainActivity.POKI_NAME_PARAM);
        String imageUrl = intent.getStringExtra("pokemonImageUrl");
        setTitle("Pokemon infos");
        TextView textViewNameP = findViewById(R.id.textViewNameP);
        textViewNameP.setText(name);
        ImageView imageView=findViewById(R.id.imagePoki);
        Glide.with(this).load(imageUrl).into(imageView);
        Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();

        //Palette.from(bitmap).generate(new Palette.PaletteAsyncListener() {
         //   @Override
          //  public void onGenerated(Palette palette) {
          //      int color = palette.getDominantColor(ContextCompat.getColor(DetailsActivity.this, R.color.black));
          //      CardView cardView = findViewById(R.id.d1);
           //     cardView.setCardBackgroundColor(color);
          //  }
        //});
    }
}
