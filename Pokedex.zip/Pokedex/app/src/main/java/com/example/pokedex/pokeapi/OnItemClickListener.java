package com.example.pokedex.pokeapi;

import com.example.pokedex.models.Pokemon;

public interface OnItemClickListener {
    void onItemClick(Pokemon pokemon);
}
